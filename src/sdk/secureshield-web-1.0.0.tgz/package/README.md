# SecureShield Web SDK (v1.0.0)
> Enterprise-Grade Client-Side Security, Anti-Tamper, Threat Detection & Zero-Trust Telemetry Engine for Web Applications.

---

## 🛡️ Overview

**SecureShield Web SDK** is a client-side security and zero-trust telemetry engine designed for modern web applications, SPAs (Single Page Applications), and Progressive Web Apps (PWAs). It provides real-time threat detection, cryptographic payload security, DOM/UI protection, runtime integrity verification, and remote threat remediation.

### 🌟 Key Capabilities & 6-Phase Architecture

| Security Phase | Feature Area | Description |
|---|---|---|
| **Phase 1** | **Identity & Handshake** | Pre-flight cryptographic origin verification, tenant binding, and hardware/browser non-extractable master key (`extractable: false`) with 24-hour IndexedDB offline grace lease fallback. |
| **Phase 2** | **E2EE Security Envelope** | Zero-trust end-to-end payload encryption using AES-256-GCM, ECDH P-256 ephemeral key exchange, and HMAC-SHA256 integrity signatures. |
| **Phase 3** | **Storage & Memory Sanitization** | `StorageScrubber` for automatic purging of unencrypted secrets (JWTs, session tokens, private keys) from `localStorage`/`sessionStorage`, and `SecureMemoryBuffer` for automated cryptographic memory zeroing. |
| **Phase 4** | **DOM & UI Hardening** | `TabBlurShield` (Web `FLAG_SECURE` equivalent blurring when tab loses focus), `SecureClipboard` with auto-wiping countdown timer (5s TTL), and SVG watermarking overlay. |
| **Phase 5** | **Runtime Integrity Guardian** | Tamper-proof proxy traps (`createTamperProofProxy`), prototype immutability (`freezePrototypes`), native function caching (`cacheNativeFunctions`), and real-time JavaScript hook detection. |
| **Phase 6** | **Remote Threat Remediation** | Dynamic OTA remediation handler (`PAUSED`, `WIPE_LOCAL_KEYS`, `TERMINATE_APP`) and full-screen Cyber Lockout Screen overlay with countdown redirects. |
| **Detectors** | **83 Engine Probes** | Automated execution of 83 Tier 1 synchronous and asynchronous client-side probes (DevTools detection, Automation/Puppeteer/Selenium, Proxy/Tampering, Canvas Fingerprinting, WebAssembly sandboxing). |

---

## 📦 Distribution Packages Included

In this distribution package, you will find:
- **`dist/`**: Compiled ES2022 JavaScript modules and complete TypeScript type declarations (`.d.ts`).
- **`secureshield-web-1.0.0.tgz`**: Ready-to-install NPM tarball package.
- **`demo.html`**: Complete, interactive 6-Phase test harness and live payload terminal for manual QA testing.
- **`start-demo.bat` / `start-demo.sh`**: 1-click local server and browser launcher for QA engineers.
- **`src/`**: Full TypeScript source code for developers and security reviewers.
- **`tests/`**: Comprehensive Vitest automated test suite with 82 unit and integration tests.
- **`TESTING_GUIDE.md`**: Complete step-by-step QA verification guide.
- **`TEST_CHECKLIST.md`**: Printable QA sign-off checklist.
- **`INTEGRATION_GUIDE.md`**: Framework integration guides for React, Next.js, Vue, Angular, and Vanilla JS.

---

## 🚀 Quick Start for Testing

### 1. Launch Interactive Demo (Zero Configuration)
Double-click `start-demo.bat` on Windows (or run `./start-demo.sh` on macOS/Linux), or execute:
```bash
npm run serve
```
Open **`http://localhost:8080/demo.html`** in your browser to interactively test all 6 security phases.

### 2. Run Automated Test Suite
```bash
npm install
npm test
```
All **82 automated tests** across 11 test suites will execute and validate the SDK components.

### 3. Install in your Project via NPM Tarball
```bash
npm install ./secureshield-web-1.0.0.tgz
# or
yarn add ./secureshield-web-1.0.0.tgz
# or
pnpm add ./secureshield-web-1.0.0.tgz
```

---

## 💻 Code Example & Basic Usage

```typescript
import { SecureShield } from '@secureshield/web';

async function initSecurity() {
  const sdk = await SecureShield.init({
    tenantId: 'TEN-ENTERPRISE-01',
    appId: 'app_web_portal_prod',
    serverUrl: 'https://security.yourcompany.com/api/v1/telemetry/ingest',
    enableStorageLeakScrubber: true,
    enableRuntimeIntegrityWatchdog: true,
    enableTabBlurShield: true,
    watermarkText: 'CONFIDENTIAL • INTERNAL USE ONLY',
    onRemediationAction: (action, reason) => {
      console.warn(`[Security Alert] Remediation action triggered: ${action} - ${reason}`);
    }
  });

  // Execute full sweep of all 83 detectors
  const report = await sdk.evaluateSecurityState();
  console.log(`Device Trust Score: ${report.trustScore}/100, Verdict: ${report.verdict}`);
}

initSecurity();
```

---

## 📚 API Reference Overview

### Core Classes & Modules

- **`SecureShield`**: Main entrypoint class. Exposes `init(config)`, `evaluateSecurityState()`, `generateReportJson()`, and `sendTelemetry()`.
- **`IndexedDbLeaseVault`**: Hardware/browser bound non-extractable CryptoKey management and encrypted offline session lease storage.
- **`PayloadSecurityHelper`**: Cryptographic envelope encryption (`sealPayload`) and decryption (`openPayload`) using AES-GCM and ECDH.
- **`StorageScrubber`**: Automated sanitization for unencrypted credentials stored in `localStorage` and `sessionStorage`.
- **`MemoryScrubber` & `SecureMemoryBuffer`**: Secure allocation and zero-fill sanitization of sensitive in-memory strings and byte buffers.
- **`TabBlurShield`**: Browser tab defocus blur privacy overlay with customizable blur radius and messaging.
- **`SecureClipboard`**: Copy sensitive data (e.g. OTPs, passwords) with automated TTL clipboard wiping.
- **`RuntimeIntegrityGuardian`**: Native function freeze, prototype tamper traps, and hook detection audits.
- **`RemediationManager`**: OTA decision response dispatcher for `ALLOW`, `CHALLENGE`, `PAUSED`, `WIPE_LOCAL_KEYS`, and `TERMINATE_APP`.
- **`SecurityLockoutOverlay`**: Full-screen lockout modal preventing user interactions when severe compromises occur.

---

## 🛡️ License & Support
- **License**: MIT
- **Author**: SecureShield Engineering & Threat Intelligence Team
- **Questions / Issues**: Refer to `TESTING_GUIDE.md` or contact the SecureShield team.
