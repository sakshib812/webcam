# SecureShield Web SDK — QA & Testing Guide

> A comprehensive testing manual for QA Engineers, Security Analysts, and Developers to validate the **SecureShield Web SDK (v1.0.0)**.

---

## 📋 Table of Contents
1. [Prerequisites & Quick Setup](#1-prerequisites--quick-setup)
2. [Automated Test Suite Execution](#2-automated-test-suite-execution)
3. [Interactive Manual Testing via `demo.html`](#3-interactive-manual-testing-via-demohtml)
4. [Phase-by-Phase Verification Scenarios](#4-phase-by-phase-verification-scenarios)
   - [Phase 1: Identity & Handshake](#phase-1-identity--handshake)
   - [Phase 2: E2EE Security Envelope](#phase-2-e2ee-security-envelope)
   - [Phase 3: Storage & Memory Scrubbing](#phase-3-storage--memory-scrubbing)
   - [Phase 4: DOM & UI Hardening](#phase-4-dom--ui-hardening)
   - [Phase 5: Runtime Integrity & Tamper Friction](#phase-5-runtime-integrity--tamper-friction)
   - [Phase 6: Remote Threat Remediation](#phase-6-remote-threat-remediation)
5. [Simulated Attack Scenarios](#5-simulated-attack-scenarios)
6. [Troubleshooting & FAQs](#6-troubleshooting--faqs)

---

## 1. Prerequisites & Quick Setup

- **Node.js**: v18.0.0 or higher (v20+ recommended)
- **Supported Browsers**:
  - Google Chrome (v100+) / Microsoft Edge (Chromium)
  - Mozilla Firefox (v100+)
  - Apple Safari (v15.4+)
- **Tools Needed**: Any standard web browser with Developer Tools (`F12`).

### Quick Launch Options
- **Windows Executable (.exe)**: Double-click `export\SecureShield-Web-Tester.exe` for instant desktop launch.
- **Testing Website (Browser)**: `npm run test:site` or open `testing-website/index.html`.
- **Legacy 6-Phase Demo**: Double-click `start-demo.bat` or open `demo.html`.
- **Manual CLI**:
  ```bash
  npm install
  npm run build
  npm run bundle
  npm run build:exe
  ```
- Open your browser to: **`http://localhost:8080/index.html`** or launch `export\SecureShield-Web-Tester.exe`.

---

## 2. Automated Test Suite Execution

The Web SDK includes an automated Vitest test suite with **82 unit and integration tests** across 11 test suites.

### Running All Tests:
```bash
npm test
```

### Expected Output Summary:
```text
✓ tests/telemetry.test.ts (3 tests)
✓ tests/vault.test.ts (5 tests)
✓ tests/crypto.test.ts (6 tests)
✓ tests/memory_scrubbing.test.ts (11 tests)
✓ tests/detectors.test.ts (14 tests)
✓ tests/runtime_integrity.test.ts (10 tests)
✓ tests/ui_hardening.test.ts (9 tests)
✓ tests/handshake.test.ts (8 tests)
✓ tests/performance.test.ts (1 test)
✓ tests/remediation.test.ts (7 tests)
✓ tests/sdk.test.ts (8 tests)

Test Files  11 passed (11)
     Tests  82 passed (82)
```

---

## 3. Interactive Manual Testing via `demo.html`

The included `demo.html` test harness is divided into 6 modular test cards corresponding to each security layer, plus a real-time payload terminal.

```
+-------------------------------------------------------------------------+
|                  SecureShield Web SDK — Test Suite                      |
+-----------------------------------+-------------------------------------+
| Phase 1: Identity & Handshake     | Phase 2: E2EE Security Envelope     |
| [Provision Lease] [Init Handshake]| [Seal Payload] [Decrypt Envelope]   |
+-----------------------------------+-------------------------------------+
| Phase 3: Storage & Memory Scrub   | Phase 4: DOM & UI Hardening         |
| [Seed Leaks] [Purge Storage]      | [Toggle Tab Blur] [Toggle Watermark]|
+-----------------------------------+-------------------------------------+
| Phase 5: Runtime Integrity        | Phase 6: Remote Threat Remediation  |
| [Audit Integrity] [Inject Hook]   | [Trigger Lockout] [Wipe Keys]       |
+-----------------------------------+-------------------------------------+
|              Live Terminal Output & Payload Inspector                   |
+-------------------------------------------------------------------------+
```

---

## 4. Phase-by-Phase Verification Scenarios

### Phase 1: Identity & Handshake
#### Test 1.1: Hardware/Browser Non-Exportable CryptoKey & IndexedDB Lease Vault
1. Click **"🔑 Provision Vault Lease"**.
2. Open Browser DevTools (`F12`) -> Go to **Application** (or **Storage**) -> **IndexedDB** -> `secureshield_auth_vault` -> `leases`.
3. **Verify**:
   - The master key is generated with `extractable: false` (hardware/browser bound).
   - An entry exists for `current_lease` containing encrypted session details and expiry timestamp.
4. Click **"🔍 Read Vault Lease"** to verify that the SDK can read and decrypt the cached lease.
5. Click **"🗑️ Clear Vault"** and verify the database is purged.

#### Test 1.2: SDK Initialization & Offline Grace Lease Fallback
1. Click **"🤝 Init SDK Handshake"**.
2. If the backend portal is running on port 4000, it performs an online handshake.
3. If the backend is offline, the SDK seamlessly falls back to the active encrypted offline grace lease provisioned in Test 1.1.

---

### Phase 2: E2EE Security Envelope
#### Test 2.1: Payload Sealing & Encryption
1. Click **"🔒 Seal & Encrypt Payload"**.
2. Look at the terminal output.
3. **Verify**:
   - The plain JSON payload is encrypted into an AES-256-GCM ciphertext.
   - An ephemeral ECDH public key is generated (`client_ephemeral_pubkey`).
   - A cryptographic HMAC-SHA256 signature is attached to prevent MITM tampering.

#### Test 2.2: Payload Decryption & Tamper Verification
1. Click **"🔓 Decrypt & Verify Envelope"**.
2. **Verify**:
   - The encrypted envelope is successfully decrypted back into the original payload object.
   - The integrity HMAC matches.

---

### Phase 3: Storage & Memory Scrubbing
#### Test 3.1: Sensitive Storage Leak Sanitization
1. Click **"⚠️ Seed Mock Leaks"**.
2. Open DevTools -> **Application** -> **Local Storage** and **Session Storage**.
3. **Verify** mock sensitive keys were seeded (e.g. `auth_jwt_token`, `oauth_refresh_token`, `aws_secret_access_key`).
4. Click **"🧹 Purge Storage Leaks"**.
5. **Verify**:
   - `StorageScrubber` scans and purges all plaintext credentials and secrets.
   - Whitelisted/safe keys (e.g. `theme_preference`, `ui_sidebar_collapsed`) remain intact.
   - The terminal shows the exact keys identified and purged with violation reasons.

#### Test 3.2: Secure Memory Zeroing
1. Click **"0️⃣ Test Memory Zero"**.
2. **Verify**:
   - `SecureMemoryBuffer` allocates a buffer, stores sensitive bytes, and subsequently executes `.zero()` to overwrite the memory space with zeroes.

---

### Phase 4: DOM & UI Hardening
#### Test 4.1: Tab Blur Shield (FLAG_SECURE Privacy Mask)
1. Click **"👁️ Toggle Tab Blur"**.
2. Switch to another browser tab or minimize/defocus the browser window.
3. **Verify**:
   - When the window loses focus, the entire page content is blurred (`backdrop-filter: blur(12px)`) with a security shield overlay message: *"🔒 SecureShield Content Hidden — Switch back to resume"*.
   - When switching back to the tab, the blur instantly clears.

#### Test 4.2: Security Watermark Overlay
1. Click **"🛡️ Toggle Watermark"**.
2. **Verify**:
   - A subtle diagonal semi-transparent security watermark (`CONFIDENTIAL • SECURESHIELD PROTECTED`) is overlaid across the viewport.
   - Pointer events pass through normally (does not block button clicks or text selection).

#### Test 4.3: Secure Clipboard with Auto-Wipe TTL
1. Click **"📋 Copy (5s TTL Wipe)"**.
2. Immediately paste (`Ctrl+V` or `Cmd+V`) into a text editor or search bar.
3. **Verify**: `SECURE_OTP_TOKEN_948201` is pasted.
4. Wait 5 seconds.
5. Try pasting (`Ctrl+V`) again.
6. **Verify**: The clipboard has been automatically wiped and cleared.

---

### Phase 5: Runtime Integrity & Tamper Friction
#### Test 5.1: Pristine Native Function Cache & Hook Detection
1. Click **"🔍 Audit Integrity"**.
2. **Verify**: Integrity status is `CLEAN` (no hooks detected on `JSON.stringify`, `fetch`, `Function.prototype`, etc.).
3. Click **"🪝 Inject API Hook"** (simulates an attacker monkey-patching `JSON.stringify`).
4. Click **"🔍 Audit Integrity"** again.
5. **Verify**:
   - The integrity engine flags the monkey-patch and reports `TAMPER_DETECTED` with the hooked symbol name.

#### Test 5.2: Tamper-Proof Proxy Traps
1. Click **"🧱 Test Proxy Trap"**.
2. **Verify**:
   - An attempt to mutate protected object properties (e.g. `proxy.tenantId = 'TEN-COMPROMISED'`) is trapped, rejected, and logged in the terminal as an integrity violation.

---

### Phase 6: Remote Threat Remediation
#### Test 6.1: Full-Screen Cyber Lockout Screen
1. Click **"🚨 Trigger Lockout Screen"**.
2. **Verify**:
   - A high-impact cyber lockout modal takes over the viewport.
   - Custom reason and security details are displayed with glowing warning indicators.
   - Click the "Dismiss Lockout (Testing Mode Only)" button to close the overlay.

#### Test 6.2: Remote Action Dispatcher (`WIPE_LOCAL_KEYS` & `PAUSED`)
1. Click **"💥 Trigger Key Wipe"**.
2. **Verify**: The remediation manager wipes cached session tokens and IndexedDB master credentials.
3. Click **"⏸️ Trigger Pause"**.
4. **Verify**: Over-the-air policy transitions the SDK into paused standby mode.

---

## 5. Simulated Attack Scenarios

| Attack Vector | Simulated Action | Expected SDK Defense |
|---|---|---|
| **Malicious Extension Hooking `fetch`** | Attacker overrides `window.fetch` | `RuntimeIntegrityGuardian` flags hooked function during audit sweep. |
| **Plaintext Credential Scraping** | Script leaves token in `localStorage` | `StorageScrubber` purges matching tokens on initialization or scheduled sweep. |
| **Shoulder Surfing / Screen Snip** | User alt-tabs or screen loses focus | `TabBlurShield` blurs sensitive viewport content with frosted overlay. |
| **Clipboard Snooping** | Background clipboard monitoring | `SecureClipboard` zeros clipboard contents after 5,000ms TTL expiration. |
| **SDK Config Tampering** | Attacker executes `SecureShield.tenantId = 'HACKED'` | `createTamperProofProxy` throws TypeError and triggers `onTamper` security callback. |
| **Compromised Device Quarantine** | Portal backend issues `TERMINATE_APP` | SDK locks DOM with `SecurityLockoutOverlay`, wipes keys, and redirects to logout URL. |

---

## 6. Troubleshooting & FAQs

### Q: Why do I see a CORS error when calling the backend?
**A:** Ensure your portal backend server is running and configured to allow the test origin (`http://localhost:8080`). For standalone local testing, use the **"🔑 Provision Vault Lease"** button to seed offline grace mode.

### Q: Can I run tests in headless mode in CI/CD?
**A:** Yes! Run `npm test` or `npx vitest run --reporter=verbose` in your CI/CD pipeline (GitHub Actions, GitLab CI, Jenkins).

---
*SecureShield Testing Guide v1.0.0 — Document Version 2026.1*
