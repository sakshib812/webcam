# SecureShield Web SDK — Framework Integration Guide

> Practical integration guides and code snippets for integrating **@secureshield/web** into React, Next.js, Vue 3, Angular, and Vanilla JavaScript web applications.

---

## 📦 1. Installation

### From Local Package Archive (.tgz):
```bash
npm install ./secureshield-web-1.0.0.tgz
```

### From Private/Public NPM Registry:
```bash
npm install @secureshield/web
```

---

## ⚛️ 2. React / Next.js Integration

### Standard React Application (`src/App.tsx` or `src/index.tsx`)
```tsx
import React, { useEffect, useState } from 'react';
import { SecureShield, SecurityAuditReport } from '@secureshield/web';

export function App() {
  const [securityReport, setSecurityReport] = useState<SecurityAuditReport | null>(null);
  const [isSecure, setIsSecure] = useState<boolean>(false);

  useEffect(() => {
    async function setupSecurity() {
      try {
        const sdk = await SecureShield.init({
          tenantId: process.env.REACT_APP_SECURESHIELD_TENANT_ID || 'TEN-PROD-001',
          appId: 'my_react_web_portal',
          serverUrl: 'https://security.mycompany.com/api/v1/telemetry/ingest',
          enableStorageLeakScrubber: true,
          enableRuntimeIntegrityWatchdog: true,
          enableTabBlurShield: true,
          watermarkText: 'CONFIDENTIAL • INTERNAL WORKSPACE',
          onRemediationAction: (action, reason) => {
            console.warn(`[Security Alert] Remediation action triggered: ${action} - ${reason}`);
          }
        });

        const report = await sdk.evaluateSecurityState();
        setSecurityReport(report);
        setIsSecure(report.verdict === 'SECURE' || report.trustScore >= 75);
      } catch (err) {
        console.error('Failed to initialize SecureShield:', err);
      }
    }

    setupSecurity();
  }, []);

  return (
    <div className="app-container">
      <header>
        <h1>My Protected Enterprise App</h1>
        <div className="status-badge">
          Security Status: {securityReport ? securityReport.verdict : 'Evaluating...'}
        </div>
      </header>
      <main>
        {/* Your application components */}
      </main>
    </div>
  );
}
```

### Next.js (App Router / Pages Router)
In Next.js, initialize SecureShield client-side in a client component or `_app.tsx` inside `useEffect`:
```tsx
'use client';

import { useEffect } from 'react';
import { SecureShield } from '@secureshield/web';

export function SecurityProvider({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    if (typeof window !== 'undefined') {
      SecureShield.init({
        tenantId: 'TEN-NEXTJS-PROD',
        appId: 'my_nextjs_app',
        serverUrl: process.env.NEXT_PUBLIC_SECURITY_INGEST_URL!,
        enableStorageLeakScrubber: true,
        enableTabBlurShield: true
      });
    }
  }, []);

  return <>{children}</>;
}
```

---

## 🟢 3. Vue 3 (Composition API / Nuxt 3)

```vue
<template>
  <div class="main-layout">
    <div class="security-indicator" :class="securityVerdict.toLowerCase()">
      Device Trust: {{ trustScore }}/100 ({{ securityVerdict }})
    </div>
    <router-view />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { SecureShield } from '@secureshield/web';

const trustScore = ref(100);
const securityVerdict = ref('INITIALIZING');

onMounted(async () => {
  try {
    const sdk = await SecureShield.init({
      tenantId: 'TEN-VUE-PROD',
      appId: 'vue_admin_dashboard',
      serverUrl: 'https://security.mycompany.com/api/v1/telemetry/ingest',
      enableStorageLeakScrubber: true,
      enableRuntimeIntegrityWatchdog: true,
      enableTabBlurShield: true
    });

    const report = await sdk.evaluateSecurityState();
    trustScore.value = report.trustScore;
    securityVerdict.value = report.verdict;
  } catch (err) {
    console.error('SecureShield initialization error:', err);
  }
});
</script>
```

---

## 🅰️ 4. Angular Integration

### `src/app/core/security.service.ts`
```typescript
import { Injectable } from '@angular/core';
import { SecureShield, SecurityAuditReport } from '@secureshield/web';

@Injectable({
  providedIn: 'root'
})
export class SecurityService {
  private sdkInstance: any = null;

  async initSecureShield(): Promise<SecurityAuditReport | null> {
    try {
      this.sdkInstance = await SecureShield.init({
        tenantId: 'TEN-ANGULAR-PROD',
        appId: 'angular_enterprise_portal',
        serverUrl: 'https://security.mycompany.com/api/v1/telemetry/ingest',
        enableStorageLeakScrubber: true,
        enableRuntimeIntegrityWatchdog: true,
        enableTabBlurShield: true
      });

      const report = await this.sdkInstance.evaluateSecurityState();
      return report;
    } catch (error) {
      console.error('SecureShield initialization failed:', error);
      return null;
    }
  }
}
```

---

## 🌐 5. Vanilla JavaScript / HTML Integration

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Protected Enterprise Portal</title>
</head>
<body>
  <h1>Secure Dashboard</h1>
  <p id="security-status">Initializing security engine...</p>

  <script type="module">
    import { SecureShield } from './dist/index.js';

    async function bootstrap() {
      const sdk = await SecureShield.init({
        tenantId: 'TEN-VANILLA-01',
        appId: 'web_portal_app',
        serverUrl: 'https://security.mycompany.com/api/v1/telemetry/ingest',
        enableStorageLeakScrubber: true,
        enableTabBlurShield: true,
        watermarkText: 'CONFIDENTIAL'
      });

      const report = await sdk.evaluateSecurityState();
      document.getElementById('security-status').textContent = 
        `Security Status: ${report.verdict} (Score: ${report.trustScore}/100)`;
    }

    bootstrap();
  </script>
</body>
</html>
```

---

## ⚙️ Configuration Reference

| Option | Type | Default | Description |
|---|---|---|---|
| `tenantId` | `string` | **(Required)** | Unique tenant identifier registered with SecureShield Portal. |
| `appId` | `string` | **(Required)** | Application identifier. |
| `serverUrl` | `string` | `undefined` | Secure ingestion endpoint for telemetry events. |
| `enableStorageLeakScrubber` | `boolean` | `true` | Scans and purges unencrypted tokens/credentials in `localStorage`/`sessionStorage`. |
| `enableRuntimeIntegrityWatchdog` | `boolean` | `true` | Monitors prototype tampering and native function hooking. |
| `enableTabBlurShield` | `boolean` | `false` | Enables `FLAG_SECURE` background tab blurring on window defocus. |
| `watermarkText` | `string` | `undefined` | Text string for the security watermark overlay. |
| `onRemediationAction` | `Function` | `undefined` | Callback invoked when remote threat policies trigger an action. |
